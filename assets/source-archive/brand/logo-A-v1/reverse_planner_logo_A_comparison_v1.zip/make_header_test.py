from pathlib import Path
import importlib.util
import cairosvg
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('la',P/'generate_logo_a_v02.py')
mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
C=mod.COLORS

def header(w):
 h=88
 t=[mod.svg_header(w,h),f'<title>Reverse Planner | {mod.SUB} | 320/390px header sample</title>',f'<rect width="{w}" height="{h}" rx="16" fill="{C["surface"]}"/>']
 t+=[f'<rect x="16" y="19" width="46" height="46" rx="10" fill="{C["line"]}" stroke="{C["edge"]}" stroke-width="2.4"/>',f'<rect x="22" y="25" width="34" height="34" rx="5" fill="{C["mintlight"]}"/>']
 group,_,_=mod.bitmap_group('RP',False,10,2.05,39,31,C['ink'])
 t.append(group)
 available=w-74-12
 main_w=mod.pixmap(mod.FULL,False,16).size[0]
 scale=min(1.08,(available-8)/main_w)
 x=(w+74)/2
 group,_,_=mod.bitmap_group(mod.FULL,False,16,scale,x,22,C['ink'])
 t.append(group)
 sub_w=mod.pixmap(mod.SUB,True,16).size[0]
 group,_,_=mod.bitmap_group(mod.SUB,True,16,min(0.9,(available-8)/sub_w),x,53,C['muted'])
 t.append(group)
 t.append(f'<rect x="0" y="86" width="{w}" height="2" fill="#D7DCCF"/>')
 t.append('</svg>');return ''.join(t)
for w in [320,390]:
 s=header(w)
 (P/f'logo_D_header_{w}.svg').write_text(s,encoding='utf-8')
 cairosvg.svg2png(bytestring=s.encode(),write_to=str(P/f'logo_D_header_{w}.png'),output_width=w*2,output_height=176)
print('done')
