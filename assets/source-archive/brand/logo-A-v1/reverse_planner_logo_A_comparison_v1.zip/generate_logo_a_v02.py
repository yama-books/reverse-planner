#!/usr/bin/env python3
"""Generate font-independent pixel-path logo experiments for Reverse Planner.

Only fonts available in the build environment are used while rasterizing; the
exported SVG wordmarks contain vector paths, not embedded font data.
"""
from __future__ import annotations
import base64, io, html, re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import cairosvg

OUT=Path(__file__).parent
FONT_EN='/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf'
FONT_JP='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
TITLE_1='Reverse'
TITLE_2='Planner'
FULL='Reverse Planner'
SUB='ギャクサンプランナー'
assert SUB == 'ギャクサンプランナー' and len(SUB)==10
COLORS={'ink':'#214B4A','mint':'#39715B','muted':'#4D665B','peach':'#E99C6A','surface':'#FFFDF7','paper':'#F6F2E8','line':'#BFE5D4','yellow':'#F6D68A','edge':'#163C3C','mintlight':'#DDF2E7'}

def svg_header(w,h):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">'

def pixmap(text, japanese, desired_h):
    face=FONT_JP if japanese else FONT_EN
    font=ImageFont.truetype(face, 42, index=0)
    bb=font.getbbox(text)
    canvas=Image.new('L',(bb[2]-bb[0]+8,bb[3]-bb[1]+8),0)
    ImageDraw.Draw(canvas).text((4-bb[0],4-bb[1]),text, font=font,fill=255)
    box=canvas.getbbox()
    assert box, text
    canvas=canvas.crop(box)
    fw,fh=canvas.size
    w=round(desired_h*fw/fh)
    down=canvas.resize((w,desired_h),Image.Resampling.LANCZOS)
    return down.point(lambda x:255 if x>130 else 0)

def mask_path(mask):
    a=mask.load(); w,h=mask.size
    rows=[]
    for y in range(h):
        x=0
        while x<w:
            if a[x,y]>0:
                start=x
                while x<w and a[x,y]>0:x+=1
                rows.append(f'M{start} {y}h{x-start}v1h{-1*(x-start)}z')
            else:x+=1
    return ' '.join(rows)

def bitmap_group(text, japanese, height_px, scale, cx, top, color, shade=None, label=None):
    mask=pixmap(text,japanese,height_px)
    w,h=mask.size
    x=cx-w*scale/2
    path=mask_path(mask)
    attrs=f' aria-label="{html.escape(label or text)}"' if label else ''
    out=[f'<g transform="translate({x:.2f} {top:.2f}) scale({scale})"{attrs}>']
    if shade: out.append(f'<path d="{path}" transform="translate(.8 .8)" fill="{shade}"/>')
    out.append(f'<path d="{path}" fill="{color}"/>')
    out.append('</g>')
    return ''.join(out),w*scale,h*scale

def star(cx,cy,s=7,color='#E99C6A'):
    # Stepped four-point pixel star, single SVG primitive path.
    p=f'M{cx-s/3:g},{cy-s:g} h{s*2/3:g} v{s*2/3:g} h{s*2/3:g} v{s*2/3:g} h{-s*2/3:g} v{s*2/3:g} h{-s*2/3:g} v{-s*2/3:g} h{-s*2/3:g} v{-s*2/3:g} h{s*2/3:g}z'
    return f'<path d="{p}" fill="{color}"/>'

def dots(x,y,steps=10,color='#BFE5D4'):
    return ''.join(f'<rect x="{x+i*12}" y="{y}" width="5" height="5" rx=".5" fill="{color}"/>' for i in range(steps))

def logo(typ, w=900, h=280, background=False):
    C=COLORS
    out=[svg_header(w,h),f'<title>Reverse Planner | {SUB} | ロゴA-{typ}</title>',f'<desc>文字情報正本 Reverse Planner / {SUB}。画面表示にフォント不要なピクセルパスで構成。</desc>']
    if background: out.append(f'<rect width="100%" height="100%" fill="{C["surface"]}"/>')
    out.append(f'<g role="img" aria-label="Reverse Planner、{SUB}">')
    center=w/2
    if typ=='01':
        a,_,_=bitmap_group(TITLE_1,False,22,4.4,center,18,C['ink'],C['line']);out.append(a)
        a,_,_=bitmap_group(TITLE_2,False,22,4.4,center,120,C['ink'],C['line']);out.append(a)
        a,_,_=bitmap_group(SUB,True,20,2.25,center,224,C['ink']);out.append(a)
        out += [star(100,65,8),star(w-103,153,6),dots(90,266,9),dots(w-204,266,9)]
    elif typ=='02':
        a,_,_=bitmap_group(TITLE_1,False,26,3.75,center,12,C['ink']);out.append(a)
        a,_,_=bitmap_group(TITLE_2,False,26,3.75,center,110,C['mint']);out.append(a)
        a,_,_=bitmap_group(SUB,True,22,2.28,center,220,C['muted']);out.append(a)
        out += [star(104,107,8,C['peach']),star(w-110,84,8,C['peach']),dots(170,273,7),dots(w-260,273,7)]
    elif typ=='03':
        a,_,_=bitmap_group(FULL,False,24,2.55,center,70,C['ink']);out.append(a)
        out.append(f'<rect x="{center-240}" y="153" width="480" height="4" rx="1" fill="{C["line"]}"/>')
        a,_,_=bitmap_group(SUB,True,22,2.07,center,185,C['ink']);out.append(a)
        out += [star(90,109,6,C['mint']),star(w-94,119,6,C['peach'])]
    else: raise ValueError(typ)
    out.append('</g></svg>')
    return ''.join(out)

for n in ['01','02','03']:
    s=logo(n)
    (OUT/f'logo_A{n}_outline.svg').write_text(s,encoding='utf-8')
    cairosvg.svg2png(bytestring=s.encode(),write_to=str(OUT/f'logo_A{n}_preview.png'),output_width=1350,output_height=420)

# Compare all three logos with explicit titles as ordinary Japanese text on a board.
# Only logo glyphs are pixel-path, all body text is explanatory.
font='Noto Sans CJK JP, sans-serif'
W,H=1600,1380
pieces=[svg_header(W,H),f'<rect width="{W}" height="{H}" fill="{COLORS["paper"]}"/>',
 f'<text x="64" y="70" font-size="37" font-weight="800" fill="{COLORS["ink"]}" font-family="{font}">Reverse Planner｜文字ロゴ A の比較</text>',
 f'<text x="64" y="116" font-size="20" fill="{COLORS["muted"]}" font-family="{font}">副題は全案「{SUB}」。英字と日本語をピクセルパスで表示。</text>']

candidates=[('A1 / ARCADE','強めの8bit感。ゲームのタイトルらしい階段状の角。','01'),('A2 / SOFT PIXEL','深青緑＋ミントの2段。UIとの親和性を重視。','02'),('A3 / COMPACT','横一列。狭い画面にも応用しやすい。','03')]
for i,(name,desc,n) in enumerate(candidates):
    y=160+i*347
    pieces.append(f'<rect x="48" y="{y}" width="1504" height="326" rx="22" fill="{COLORS["surface"]}" stroke="#C6D5CA" stroke-width="2"/>')
    pieces.append(f'<rect x="70" y="{y+22}" width="104" height="37" rx="12" fill="{COLORS["line"]}"/>')
    pieces.append(f'<text x="82" y="{y+48}" font-family="{font}" font-size="20" font-weight="700" fill="{COLORS["ink"]}">{name.split(" / ")[0]}</text>')
    pieces.append(f'<text x="187" y="{y+47}" font-family="{font}" font-size="19" font-weight="700" fill="{COLORS["ink"]}">{name.split(" / ")[1]}</text>')
    pieces.append(f'<text x="190" y="{y+84}" font-family="{font}" font-size="16" fill="{COLORS["muted"]}">{desc}</text>')
    svg=logo(n)
    data=base64.b64encode(cairosvg.svg2png(bytestring=svg.encode(),output_width=880,output_height=274)).decode()
    pieces.append(f'<image x="115" y="{y+88}" width="930" height="235" href="data:image/png;base64,{data}"/>')
    pieces.append(f'<line x1="1093" y1="{y+18}" x2="1093" y2="{y+301}" stroke="#D8E3DB" stroke-width="2"/>')
    pieces.append(f'<text x="1123" y="{y+70}" font-family="{font}" font-size="18" fill="{COLORS["ink"]}" font-weight="700">小画面の文字品質</text>')
    # For the shrunk wordmark, crop? display from actual logo at small presentation width.
    pieces.append(f'<rect x="1120" y="{y+91}" width="392" height="104" rx="14" fill="#DDF2E7"/>')
    pieces.append(f'<image x="1135" y="{y+105}" width="360" height="78" href="data:image/png;base64,{data}"/>')
    pieces.append(f'<text x="1135" y="{y+239}" font-family="{font}" font-size="16" fill="{COLORS["muted"]}">横幅360pxの縮小例</text>')

basey=1229
pieces.append(f'<rect x="48" y="{basey}" width="1504" height="102" rx="20" fill="#DDF2E7"/>')
pieces.append(f'<text x="75" y="{basey+39}" font-family="{font}" font-size="18" font-weight="700" fill="{COLORS["ink"]}">推奨の検討順：A2（第一候補）→ A1（ゲーム性）→ A3（小画面）</text>')
pieces.append(f'<text x="75" y="{basey+74}" font-family="{font}" font-size="17" fill="{COLORS["muted"]}">文字は誤字なし。最終書体はDotGothic16・Pixelify Sansとの比較後に固定。装飾ネコは次工程。</text>')
pieces.append('</svg>')
board=''.join(pieces)
(OUT/'logo_A_compare.svg').write_text(board,encoding='utf-8')
cairosvg.svg2png(bytestring=board.encode(),write_to=str(OUT/'logo_A_compare.png'))
print('Created', [x.name for x in OUT.glob('logo_A*')])
